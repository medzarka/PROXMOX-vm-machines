The **basic docker template** is a template for a basic debian system.

We aim to install vscode-web for file managin and terminal access.

In vscode-web, we aim mainly to get access to bash files for configuring a linix system.
A git package will be required to push and pull repositories.

To export the template, type the following command within the template dir:

    tar cvf ../basic_docker_template.tar .**

